package com.scaleui.launcher.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Spec section 3 (App Drawer) + section 5 (Settings > Home Screen
 * Controls) both call for a user-facing icon shape option. DrawerIcon
 * already accepted a `slotShape: Shape` param since Part 4 for exactly
 * this — Part 11 is what finally drives it from a real setting instead of
 * a hardcoded default.
 */
enum class IconShape {
    CIRCLE,
    SQUIRCLE,
    ROUNDED_SQUARE,
    SQUARE;

    fun toComposeShape(): Shape = when (this) {
        CIRCLE -> CircleShape
        SQUIRCLE -> RoundedCornerShape(30)
        ROUNDED_SQUARE -> RoundedCornerShape(16.dp)
        SQUARE -> RoundedCornerShape(2.dp)
    }
}

/** Read anywhere below ScaleTheme with `LocalIconShape.current`. */
val LocalIconShape = compositionLocalOf { IconShape.CIRCLE }
