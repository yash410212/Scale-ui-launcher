package com.scaleui.launcher.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scaleui.launcher.animation.AnimationMode
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.home.model.HomeGridConfig
import com.scaleui.launcher.theme.IconShape
import com.scaleui.launcher.theme.ThemeMode
import com.scaleui.launcher.widgets.ScaleWidgetType
import com.scaleui.launcher.widgets.WidgetSize
import com.scaleui.launcher.widgets.WidgetPlacement
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Backs SettingsScreen. Every field here is a thin StateFlow over
 * SettingsRepository plus a setter that launches a suspend write — the
 * repository is the only thing that talks to DataStore.
 */
class SettingsViewModel(private val repository: SettingsRepository) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> = repository.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.GLASS)

    val isDarkMode: StateFlow<Boolean> = repository.isDarkMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val iconShape: StateFlow<IconShape> = repository.iconShape
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), IconShape.CIRCLE)

    val gridConfig: StateFlow<HomeGridConfig> = repository.homeGridConfig
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeGridConfig())

    val animationMode: StateFlow<AnimationMode> = repository.animationMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AnimationMode.BALANCED)

    val homeWidgets: StateFlow<List<WidgetPlacement>> = repository.homeWidgets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addWidget(type: ScaleWidgetType) { viewModelScope.launch { repository.addHomeWidget(type) } }
    fun removeWidget(type: ScaleWidgetType) { viewModelScope.launch { repository.removeHomeWidget(type) } }
    fun resizeWidget(type: ScaleWidgetType, size: WidgetSize) { viewModelScope.launch { repository.resizeHomeWidget(type, size) } }

    fun onAnimationModeSelected(mode: AnimationMode) {
        viewModelScope.launch { repository.setAnimationMode(mode) }
    }

    val gestureMap: StateFlow<Map<com.scaleui.launcher.special.GestureTrigger, com.scaleui.launcher.special.GestureAction>> =
        repository.gestureMap.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.scaleui.launcher.special.DEFAULT_GESTURE_MAP)

    fun onGestureActionSelected(trigger: com.scaleui.launcher.special.GestureTrigger, action: com.scaleui.launcher.special.GestureAction) {
        viewModelScope.launch { repository.setGestureAction(trigger, action) }
    }

    fun onThemeModeSelected(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun onDarkModeToggled(isDark: Boolean) {
        viewModelScope.launch { repository.setDarkMode(isDark) }
    }

    fun onIconShapeSelected(shape: IconShape) {
        viewModelScope.launch { repository.setIconShape(shape) }
    }

    fun onGridSizeChanged(columns: Int, rows: Int) {
        viewModelScope.launch { repository.setGridSize(columns, rows) }
    }
}
