package com.scaleui.launcher.zeroscreen

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface
import java.util.concurrent.TimeUnit

/**
 * Zero Screen's app-usage card. Needs PACKAGE_USAGE_STATS (special access,
 * granted via system Settings, not a normal manifest permission) —
 * degrades to "Usage access not granted" instead of crashing if absent.
 */
@Composable
fun ScreenTimeCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val topApps = remember { queryTopAppsToday(context) }

    GlassSurface(modifier = modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(16.dp)) {
            Text("App Usage", style = MaterialTheme.typography.titleSmall)
            if (topApps.isEmpty()) {
                Text("Usage access not granted", style = MaterialTheme.typography.bodySmall)
            } else {
                topApps.forEach { (label, minutes) ->
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text("${minutes}m", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

private fun hasUsageAccess(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

private fun queryTopAppsToday(context: Context): List<Pair<String, Long>> {
    if (!hasUsageAccess(context)) return emptyList()
    return runCatching {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - TimeUnit.DAYS.toMillis(1)
        val pm = context.packageManager
        usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
            .filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }
            .take(3)
            .map { stat ->
                val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(stat.packageName, 0)).toString() }
                    .getOrDefault(stat.packageName)
                label to TimeUnit.MILLISECONDS.toMinutes(stat.totalTimeInForeground)
            }
    }.getOrDefault(emptyList())
}
