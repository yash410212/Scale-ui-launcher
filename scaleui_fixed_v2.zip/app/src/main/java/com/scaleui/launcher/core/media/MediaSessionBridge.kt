package com.scaleui.launcher.core.media

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Bridges to whichever app is currently playing media (YT Music, Spotify,
 * etc.) via the system's active MediaSessions — this is what lets the two
 * final music widget designs control "any" app rather than one hardcoded
 * player. Needs Notification Access permission; if not granted, methods
 * degrade to no-ops instead of crashing.
 */
class MediaSessionBridge(private val context: Context) {

    private val _activeController = MutableStateFlow<MediaController?>(null)
    val activeController: StateFlow<MediaController?> = _activeController.asStateFlow()

    fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: ""
        return enabled.contains(context.packageName)
    }

    /** Call to (re)scan for the current active session — e.g. on Zero Screen / widget composition. */
    fun refresh() {
        if (!hasNotificationAccess()) {
            _activeController.value = null
            return
        }
        runCatching {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(context, ScaleNotificationListenerService::class.java)
            val sessions = manager.getActiveSessions(component)
            _activeController.value = sessions.firstOrNull { it.playbackState != null }
        }.onFailure { _activeController.value = null }
    }

    fun togglePlayPause() {
        val controller = _activeController.value ?: return
        val isPlaying = controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
        if (isPlaying) controller.transportControls.pause() else controller.transportControls.play()
    }

    fun skipNext() = _activeController.value?.transportControls?.skipToNext()
    fun skipPrevious() = _activeController.value?.transportControls?.skipToPrevious()
}
