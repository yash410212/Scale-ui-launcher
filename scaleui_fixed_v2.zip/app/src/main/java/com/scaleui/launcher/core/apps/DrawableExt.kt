package com.scaleui.launcher.core.apps

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable

/**
 * Shared by HomeIcon and (from Part 4) DrawerIcon — previously duplicated
 * privately in each file. Any future icon-pack rendering (custom icon
 * shapes/packs, Part 6+ theme engine) hooks in here instead of at each
 * call site.
 */
fun Drawable.toBitmapCached(): Bitmap {
    val width = intrinsicWidth.coerceAtLeast(1)
    val height = intrinsicHeight.coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap
}
