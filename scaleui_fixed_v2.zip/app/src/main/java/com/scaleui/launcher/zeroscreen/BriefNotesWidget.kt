package com.scaleui.launcher.zeroscreen

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface

/** Zero Screen's quick-notes card. Persisted via SettingsRepository.briefNote. */
@Composable
fun BriefNotesWidget(text: String, onTextChange: (String) -> Unit, modifier: Modifier = Modifier) {
    GlassSurface(modifier = modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(16.dp)) {
            Text("Brief Notes", style = MaterialTheme.typography.titleSmall)
            BasicTextField(
                value = text,
                onValueChange = onTextChange,
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }
    }
}
