package com.scaleui.launcher.zeroscreen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.widgets.clock.ClockWidget

/**
 * Spec section 2: dedicated Zero Screen — screen time, brief notes,
 * calendar, widgets (music). Reached via swipe-down on Home (Part 12).
 */
@Composable
fun ZeroScreenScreen(viewModel: ZeroScreenViewModel, modifier: Modifier = Modifier) {
    val note by viewModel.briefNote.collectAsState()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ClockWidget() }
        item { ScreenTimeCard() }
        item { BriefNotesWidget(text = note, onTextChange = viewModel::onNoteChange) }
        item { ZeroMusicWidget() }
        item { ZeroCalendarWidget() }
    }
}
