package com.scaleui.launcher.folders

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.toBitmapCached

/**
 * Locked design: folder shown on Home as a fanned/overlapping stack of up
 * to 4 icons (rotated/offset) inside a translucent rounded backdrop — not
 * a plain grid-in-circle. Tap opens FolderOpenScreen.
 */
@Composable
fun FolderPreview(folder: ScaleFolder, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.18f)),
        ) {
            val preview = folder.apps.take(4)
            val offsets = listOf(-6f to -6f, 6f to -4f, -4f to 6f, 5f to 5f)
            preview.forEachIndexed { index, app ->
                val (dx, dy) = offsets.getOrElse(index) { 0f to 0f }
                val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
                Image(
                    painter = BitmapPainter(bitmap.asImageBitmap()),
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(26.dp)
                        .align(Alignment.Center)
                        .offset(dx.dp, dy.dp)
                        .clip(RoundedCornerShape(6.dp)),
                )
            }
        }
        Text(
            text = folder.name,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.size(width = 64.dp, height = 16.dp),
        )
    }
}
