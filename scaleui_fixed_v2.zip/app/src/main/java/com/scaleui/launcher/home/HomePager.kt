package com.scaleui.launcher.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.folders.ScaleFolder
import com.scaleui.launcher.home.model.HomeLayoutState
import com.scaleui.launcher.widgets.ScaleWidgetCard
import com.scaleui.launcher.widgets.WidgetPlacement

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomePager(
    pages: List<HomeLayoutState>,
    onAppClick: (AppInfo) -> Unit,
    onFolderClick: (ScaleFolder) -> Unit,
    onMoveApp: (String, String) -> Unit = { _, _ -> },
    homeWidgets: List<WidgetPlacement> = emptyList(),
    modifier: Modifier = Modifier,
) {
    val pagerState = rememberPagerState(pageCount = { pages.size.coerceAtLeast(1) })
    Column(modifier = modifier.fillMaxSize()) {
        if (homeWidgets.isNotEmpty()) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                homeWidgets.forEach { placement ->
                    ScaleWidgetCard(placement = placement, showControls = false)
                }
            }
        }
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f).fillMaxSize(),
        ) { pageIndex ->
            if (pageIndex < pages.size) {
                HomeGrid(
                    layout = pages[pageIndex],
                    onAppClick = onAppClick,
                    onFolderClick = onFolderClick,
                    onMoveApp = onMoveApp,
                )
            }
        }
        if (pages.size > 1) {
            PageIndicator(
                pageCount = pages.size,
                currentPage = pagerState.currentPage,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            )
        }
    }
}

@Composable
private fun PageIndicator(pageCount: Int, currentPage: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
        repeat(pageCount) { index ->
            val active = index == currentPage
            Box(
                modifier = Modifier.size(if (active) 7.dp else 5.dp).clip(CircleShape).background(
                    if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                )
            )
        }
    }
}
