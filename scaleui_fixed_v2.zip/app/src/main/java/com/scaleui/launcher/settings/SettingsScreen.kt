package com.scaleui.launcher.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface
import com.scaleui.launcher.theme.IconShape
import com.scaleui.launcher.theme.ThemeMode
import com.scaleui.launcher.profiles.Profile
import com.scaleui.launcher.profiles.ProfileManager
import com.scaleui.launcher.animation.AnimationMode
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.input.PasswordVisualTransformation

/**
 * Settings, per spec section 5: General (Dark/Light) + Home Screen
 * Controls (icon shape, grid size) live here. Theme selection is also
 * here even though spec lists "Theme Settings" as its own sub-section —
 * with only 5 modes total it doesn't need a separate screen yet; splitting
 * it out later is just moving this one Composable, not rewriting it.
 *
 * Widget controls are included here; drawer transparency remains directly accessible from the Drawer.
 */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel, profileManager: ProfileManager, modifier: Modifier = Modifier) {
    val themeMode by viewModel.themeMode.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val iconShape by viewModel.iconShape.collectAsState()
    val gridConfig by viewModel.gridConfig.collectAsState()
    val currentProfile by profileManager.currentProfile.collectAsState()
    val hasPinSet by profileManager.hasPinSet.collectAsState()
    val pinError by profileManager.pinError.collectAsState()
    val animationMode by viewModel.animationMode.collectAsState()
    val homeWidgets by viewModel.homeWidgets.collectAsState()
    var pinInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var newPinInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SettingsSection(title = "General") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Dark theme", style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = isDarkMode, onCheckedChange = viewModel::onDarkModeToggled)
                }
            }
        }

        item {
            SettingsSection(title = "Theme") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ThemeMode.values().forEach { mode ->
                        ThemeSwatch(
                            mode = mode,
                            isSelected = mode == themeMode,
                            onClick = { viewModel.onThemeModeSelected(mode) },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Home Screen — Icon Shape") {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    IconShape.values().forEach { shape ->
                        IconShapeSwatch(
                            shape = shape,
                            isSelected = shape == iconShape,
                            onClick = { viewModel.onIconShapeSelected(shape) },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Home Screen — Grid Size") {
                Column {
                    Text(
                        "Columns: ${gridConfig.columns}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = gridConfig.columns.toFloat(),
                        valueRange = 1f..10f,
                        steps = 8,
                        onValueChange = {
                            viewModel.onGridSizeChanged(it.toInt(), gridConfig.rows)
                        },
                    )
                    Text(
                        "Rows: ${gridConfig.rows}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = gridConfig.rows.toFloat(),
                        valueRange = 1f..10f,
                        steps = 8,
                        onValueChange = {
                            viewModel.onGridSizeChanged(gridConfig.columns, it.toInt())
                        },
                    )
                }
            }
        }

        item {
            SettingsSection(title = "Home Widgets") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.scaleui.launcher.widgets.ScaleWidgetType.values().forEach { type ->
                        val placement = homeWidgets.firstOrNull { it.type == type }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(type.name.replace('_', ' '))
                            if (placement == null) {
                                Text("Add", modifier = Modifier.clickable { viewModel.addWidget(type) })
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    com.scaleui.launcher.widgets.WidgetSize.values().forEach { size ->
                                        Text(size.name.take(1), modifier = Modifier.clickable { viewModel.resizeWidget(type, size) })
                                    }
                                    Text("×", modifier = Modifier.clickable { viewModel.removeWidget(type) })
                                }
                            }
                        }
                    }
                    Text("Widgets appear above the app grid on Home. Long-press an app to move it.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            SettingsSection(title = "Profile") {
                Column {
                    Text("Active: ${currentProfile.name}", style = MaterialTheme.typography.bodyLarge)
                    val target = if (currentProfile == Profile.PROFILE_1) Profile.PROFILE_2 else Profile.PROFILE_1

                    if (!hasPinSet) {
                        Text("No PIN set — set one to protect profile switching:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                        BasicTextField(
                            value = newPinInput,
                            onValueChange = { newPinInput = it },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        )
                        Text(
                            "Save PIN",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 8.dp).clickable {
                                if (newPinInput.isNotBlank()) profileManager.setPin(newPinInput)
                            },
                        )
                        Text(
                            "Switch to $target (no PIN yet)",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 12.dp).clickable { profileManager.switchProfileUnlocked(target) },
                        )
                    } else {
                        Text("Enter PIN to switch to $target:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                        BasicTextField(
                            value = pinInput,
                            onValueChange = { pinInput = it },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        )
                        if (pinError) Text("Wrong PIN", color = Color.Red, style = MaterialTheme.typography.labelSmall)
                        Text(
                            "Switch",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 8.dp).clickable {
                                profileManager.attemptSwitchWithPin(target, pinInput)
                            },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Animation Performance") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AnimationMode.values().forEach { mode ->
                        Text(
                            text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelLarge,
                            color = if (mode == animationMode) Color.White else Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.clickable { viewModel.onAnimationModeSelected(mode) },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Gestures") {
                val gestureMap by viewModel.gestureMap.collectAsState()
                com.scaleui.launcher.special.GestureTrigger.values().forEach { trigger ->
                    val current = gestureMap[trigger] ?: com.scaleui.launcher.special.GestureAction.NONE
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(trigger.name.replace('_', ' '), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            current.name.replace('_', ' '),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.clickable {
                                val actions = com.scaleui.launcher.special.GestureAction.values()
                                val next = actions[(actions.indexOf(current) + 1) % actions.size]
                                viewModel.onGestureActionSelected(trigger, next)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    GlassSurface(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 12.dp),
            )
            content()
        }
    }
}

@Composable
private fun ThemeSwatch(mode: ThemeMode, isSelected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.15f))
                .clickable(onClick = onClick),
        )
        Text(
            text = mode.name.take(1) + mode.name.drop(1).lowercase().replace('_', ' '),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun IconShapeSwatch(shape: IconShape, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(shape.toComposeShape())
            .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.3f))
            .clickable(onClick = onClick),
    )
}
