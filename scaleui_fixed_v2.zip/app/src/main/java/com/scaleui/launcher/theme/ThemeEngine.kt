package com.scaleui.launcher.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Resolves [ThemeMode] -> [GlassConfig].
 *
 * Part 6 scope: skeleton values that make all 4 themes visually distinct
 * and roughly match their reference images. Parts 7-10 each take one
 * theme and refine its exact tokens (precise colors, blur behavior on
 * different backgrounds, etc.) — this function is the one place those
 * refinements land; nothing else changes.
 */
object ThemeEngine {

    fun configFor(mode: ThemeMode, custom: CustomThemeConfig = CustomThemeConfig()): GlassConfig =
        when (mode) {
            ThemeMode.FROST_GLASS -> GlassConfig(
                backgroundTint = Color.White,
                tintAlpha = 0.20f,
                blurRadius = 28.dp,       // soft glow blur, per the "Frosted" reference
                borderColor = Color.White.copy(alpha = 0.5f),
                borderWidth = 1.dp,
                cornerRadius = 28.dp,
            )

            ThemeMode.LIQUID_GLASS -> GlassConfig(
                backgroundTint = Color.White,
                tintAlpha = 0.08f,        // crisp/clear, minimal tint — per the "Clear/iOS" reference
                blurRadius = 3.dp,
                borderColor = Color.White.copy(alpha = 0.7f),
                borderWidth = 1.2.dp,
                cornerRadius = 26.dp,
                hasSpecularHighlight = true,
            )

            ThemeMode.GLASS -> GlassConfig(
                backgroundTint = Color(0xFF17171C),
                tintAlpha = 0.30f,        // colorful bleed-through cards + component sheet reference
                blurRadius = 12.dp,
                borderColor = Color.White.copy(alpha = 0.28f),
                borderWidth = 1.dp,
                cornerRadius = 20.dp,
                hasCornerHighlight = true,
            )

            ThemeMode.BLUR_MIST -> GlassConfig(
                backgroundTint = Color(0xFF0A0A0C),
                tintAlpha = 0.50f,        // heavy bokeh blur, per the "Blur/One UI" reference
                blurRadius = 44.dp,
                borderColor = Color.Transparent,
                borderWidth = 0.dp,
                cornerRadius = 26.dp,
                hasMistVignette = true,
            )

            ThemeMode.CUSTOM -> GlassConfig(
                backgroundTint = custom.backgroundTint,
                tintAlpha = custom.transparency,
                blurRadius = custom.blurRadius,
                borderColor = custom.borderColor.copy(alpha = 0.3f),
                borderWidth = 1.dp,
                cornerRadius = custom.cornerRadius,
            )
        }
}
