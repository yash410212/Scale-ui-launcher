package com.scaleui.launcher.core

import android.app.Application

/**
 * Application entry point.
 *
 * Currently empty on purpose — this is where later parts will wire up:
 *   - AppRepository singleton (app discovery)
 *   - SettingsDataStore / LauncherDatabase
 *   - AppStateHolder (current theme, current profile, animation mode)
 *
 * Kept minimal in Part 1 so nothing here has to be rewritten later; new
 * pieces get added, existing ones don't need to change shape.
 */
class ScaleUIApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Deliberately empty for Part 1.
    }
}
