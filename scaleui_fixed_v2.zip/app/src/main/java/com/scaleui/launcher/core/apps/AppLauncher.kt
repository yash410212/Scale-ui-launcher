package com.scaleui.launcher.core.apps

import android.content.Context
import android.content.Intent

/**
 * Launches an app from its [AppInfo]. Kept as a tiny standalone object
 * (rather than a method on AppRepository) so home/drawer/folders can all
 * call the same launch path without depending on the repository.
 */
object AppLauncher {

    fun launch(context: Context, app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityClassName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        runCatching {
            context.startActivity(intent)
        }
        // Silent failure by design for Part 1 — a "couldn't open app" Snackbar/Toast
        // gets wired up once the Home/Drawer screens exist to show it from.
    }
}
