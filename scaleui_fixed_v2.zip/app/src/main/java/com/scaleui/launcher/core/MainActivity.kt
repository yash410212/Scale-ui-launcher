package com.scaleui.launcher.core

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.scaleui.launcher.core.apps.AppRepository
import com.scaleui.launcher.core.navigation.ScaleNavHost
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.settings.SettingsViewModel
import com.scaleui.launcher.theme.ScaleTheme

/**
 * Single Activity host for the whole launcher.
 *
 * Part 3: FLAG_SHOW_WALLPAPER + transparent Surface so the system
 * wallpaper shows through.
 *
 * Part 4: content is ScaleNavHost (Home <-> App Drawer).
 *
 * Part 6: MaterialTheme swapped for ScaleTheme.
 *
 * Part 11: theme mode / dark mode / icon shape now come from
 * SettingsViewModel (DataStore-backed, persisted) instead of the
 * temporary dev-only switcher Part 7 added — that switcher and its local
 * state are gone. AppRepository and SettingsRepository are both created
 * once here and threaded down so every screen shares the same instances
 * instead of each re-creating its own.
 */
class MainActivity : ComponentActivity() {

    private val appRepository by lazy { AppRepository(applicationContext) }
    private val settingsRepository by lazy { SettingsRepository(applicationContext) }

    private val settingsViewModel: SettingsViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return SettingsViewModel(settingsRepository) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)

        setContent {
            val themeMode by settingsViewModel.themeMode.collectAsState()
            val isDarkMode by settingsViewModel.isDarkMode.collectAsState()
            val iconShape by settingsViewModel.iconShape.collectAsState()
            val animationMode by settingsViewModel.animationMode.collectAsState()

            ScaleTheme(
                themeMode = themeMode,
                isDarkMode = isDarkMode,
                iconShape = iconShape,
                animationMode = animationMode,
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent,
                ) {
                    ScaleNavHost(
                        appRepository = appRepository,
                        settingsRepository = settingsRepository,
                    )
                }
            }
        }
    }
}
