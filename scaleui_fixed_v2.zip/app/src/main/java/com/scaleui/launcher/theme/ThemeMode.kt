package com.scaleui.launcher.theme

/**
 * The 4 built-in themes locked from Yash's design references, plus Custom
 * (spec section 4 — user-built theme, controls added over time in later
 * parts).
 *
 * Mapping to the design references (see /areas/scale-ui.md for the source
 * images): FROST_GLASS = the "Frosted" concept card (soft glow blur),
 * LIQUID_GLASS = the "Clear/iOS" concept card (sharp, crisp refractive
 * glass — matches Apple's actual "Liquid Glass" design language),
 * GLASS = the colorful translucent cards with blob bleed-through + thin
 * border + the glass component sheet, BLUR_MIST = the "Blur/One UI"
 * concept card (heavy bokeh blur).
 */
enum class ThemeMode {
    FROST_GLASS,
    LIQUID_GLASS,
    GLASS,
    BLUR_MIST,
    CUSTOM,
}
