package com.scaleui.launcher.animation

import androidx.compose.runtime.compositionLocalOf

/** Spec section 8: Light (low-end, minimal effects) / Balanced / Smooth / Custom. */
enum class AnimationMode { LIGHT, BALANCED, SMOOTH, CUSTOM }

/** Concrete values GlassSurface + page transitions read — resolved from AnimationMode. */
data class AnimationConfig(
    val transitionDurationMs: Int,
    val blurEnabled: Boolean,
)

fun AnimationMode.toConfig(): AnimationConfig = when (this) {
    AnimationMode.LIGHT -> AnimationConfig(transitionDurationMs = 120, blurEnabled = false) // no blur at all on low-end
    AnimationMode.BALANCED -> AnimationConfig(transitionDurationMs = 220, blurEnabled = true)
    AnimationMode.SMOOTH -> AnimationConfig(transitionDurationMs = 340, blurEnabled = true)
    AnimationMode.CUSTOM -> AnimationConfig(transitionDurationMs = 220, blurEnabled = true) // per-field custom controls: later refinement
}

val LocalAnimationConfig = compositionLocalOf { AnimationMode.BALANCED.toConfig() }
