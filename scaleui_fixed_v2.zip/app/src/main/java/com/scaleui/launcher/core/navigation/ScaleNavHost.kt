package com.scaleui.launcher.core.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.scaleui.launcher.core.apps.AppRepository
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.drawer.AppDrawerScreen
import com.scaleui.launcher.drawer.AppDrawerViewModel
import com.scaleui.launcher.home.HomePagerViewModel
import com.scaleui.launcher.home.HomeScreen
import com.scaleui.launcher.profiles.ProfileManager
import com.scaleui.launcher.settings.SettingsScreen
import com.scaleui.launcher.settings.SettingsViewModel
import com.scaleui.launcher.zeroscreen.ZeroScreenScreen
import com.scaleui.launcher.zeroscreen.ZeroScreenViewModel

private const val ROUTE_HOME = "home"
private const val ROUTE_DRAWER = "drawer"
private const val ROUTE_SETTINGS = "settings"
private const val ROUTE_ZERO_SCREEN = "zero_screen"

/** Four destinations: Home, App Drawer, Settings, Zero Screen. */
@Composable
fun ScaleNavHost(appRepository: AppRepository, settingsRepository: SettingsRepository) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = ROUTE_HOME) {
        composable(ROUTE_HOME) {
            val viewModel: HomePagerViewModel = viewModel(
                factory = factoryFor { HomePagerViewModel(appRepository, settingsRepository) },
            )
            HomeScreen(
                viewModel = viewModel,
                settingsRepository = settingsRepository,
                onOpenDrawer = { navController.navigate(ROUTE_DRAWER) },
                onOpenSettings = { navController.navigate(ROUTE_SETTINGS) },
                onOpenZeroScreen = { navController.navigate(ROUTE_ZERO_SCREEN) },
            )
        }
        composable(ROUTE_DRAWER) {
            val viewModel: AppDrawerViewModel = viewModel(
                factory = factoryFor { AppDrawerViewModel(appRepository, settingsRepository) },
            )
            AppDrawerScreen(viewModel = viewModel)
        }
        composable(ROUTE_SETTINGS) {
            val settingsViewModel: SettingsViewModel = viewModel(factory = factoryFor { SettingsViewModel(settingsRepository) })
            val profileManager: ProfileManager = viewModel(factory = factoryFor { ProfileManager(settingsRepository) })
            SettingsScreen(viewModel = settingsViewModel, profileManager = profileManager)
        }
        composable(ROUTE_ZERO_SCREEN) {
            val viewModel: ZeroScreenViewModel = viewModel(factory = factoryFor { ZeroScreenViewModel(settingsRepository) })
            ZeroScreenScreen(viewModel = viewModel)
        }
    }
}

private fun <T : ViewModel> factoryFor(create: () -> T): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        override fun <VM : ViewModel> create(modelClass: Class<VM>): VM {
            @Suppress("UNCHECKED_CAST")
            return create() as VM
        }
    }
