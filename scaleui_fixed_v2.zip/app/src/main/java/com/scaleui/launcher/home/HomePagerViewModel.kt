package com.scaleui.launcher.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.AppRepository
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.home.model.HomeCellItem
import com.scaleui.launcher.home.model.HomeGridConfig
import com.scaleui.launcher.home.model.HomeIconPlacement
import com.scaleui.launcher.home.model.HomeLayoutState
import com.scaleui.launcher.profiles.filterForProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Holds one [HomeLayoutState] per page. Grid size + icon shape settings-driven
 * (Part 11). Auto-fill placement, "More" folder demo (Part 12), and now
 * (Part 17) apps are filtered by current profile + per-app visibility
 * before being placed at all — a HIDDEN or wrong-profile app simply never
 * appears in the auto-fill.
 */
class HomePagerViewModel(
    private val appRepository: AppRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _pages = MutableStateFlow<List<HomeLayoutState>>(listOf(HomeLayoutState()))
    val pages: StateFlow<List<HomeLayoutState>> = _pages.asStateFlow()

    init {
        viewModelScope.launch {
            appRepository.refresh()
            combine(
                appRepository.installedApps,
                settingsRepository.homeGridConfig,
                settingsRepository.currentProfile,
                settingsRepository.appVisibilityMap,
                settingsRepository.homeOrder,
            ) { apps, config, profile, visibilityMap, order ->
                val visible = filterForProfile(apps, profile, visibilityMap)
                val orderIndex = order.withIndex().associate { it.value to it.index }
                buildPages(visible.sortedBy { orderIndex[it.packageName] ?: Int.MAX_VALUE }, config)
            }.collect { _pages.value = it }
        }
    }

    private fun buildPages(apps: List<AppInfo>, config: HomeGridConfig): List<HomeLayoutState> {
        val capacity = (config.columns * config.rows).coerceAtLeast(1)
        if (apps.isEmpty()) return listOf(HomeLayoutState(gridConfig = config))
        return apps.chunked(capacity).map { pageApps ->
            HomeLayoutState(
                gridConfig = config,
                placements = pageApps.mapIndexed { i, app ->
                    HomeIconPlacement(HomeCellItem.AppItem(app), i / config.columns, i % config.columns)
                },
            )
        }
    }

    fun moveApp(fromPackage: String, toPackage: String) {
        if (fromPackage == toPackage) return
        viewModelScope.launch {
            val current = _pages.value.flatMap { page ->
                page.placements.mapNotNull {
                    (it.item as? HomeCellItem.AppItem)?.app?.packageName
                }
            }.toMutableList()
            val from = current.indexOf(fromPackage)
            val to = current.indexOf(toPackage)
            if (from < 0 || to < 0) return@launch
            current[from] = current[to].also { current[to] = current[from] }
            settingsRepository.setHomeOrder(current)
        }
    }

}
