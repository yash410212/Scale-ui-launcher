package com.scaleui.launcher.folders

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppLauncher
import com.scaleui.launcher.drawer.DrawerIcon
import com.scaleui.launcher.theme.GlassSurface

/**
 * Open-folder screen, locked design: dark card over most of the screen,
 * app grid + name as title, dismiss (back/tap-outside handled by caller
 * via [onDismiss]). Swiping to adjacent folders is a later refinement —
 * this shows one folder per call, which is what HomeScreen currently
 * needs.
 */
@Composable
fun FolderOpenScreen(folder: ScaleFolder, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    GlassSurface(modifier = modifier.fillMaxSize(), shape = RectangleShape, alphaOverride = 0.55f) {
        androidx.compose.foundation.layout.Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text(text = folder.name, style = MaterialTheme.typography.titleLarge)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize().padding(top = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(folder.apps, key = { it.packageName }) { app ->
                    DrawerIcon(app = app, onClick = { AppLauncher.launch(context, app); onDismiss() })
                }
            }
        }
    }
}
