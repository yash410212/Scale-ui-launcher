package com.scaleui.launcher.core.apps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Single source of truth for "what apps are installed on this device".
 *
 * Home screen, App Drawer, and Zero Screen's App Usage card all read from
 * this repository rather than querying PackageManager themselves — keeps
 * app discovery in one place, and means a future install/uninstall
 * BroadcastReceiver only has to update one list.
 */
class AppRepository(private val context: Context) {

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    /** Loads (or reloads) the full list of launchable apps. Call off the main thread. */
    suspend fun refresh() {
        val apps = withContext(Dispatchers.Default) {
            queryLaunchableApps()
        }
        _installedApps.value = apps
    }

    private fun queryLaunchableApps(): List<AppInfo> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolvedActivities = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)

        return resolvedActivities
            .mapNotNull { resolveInfo ->
                val activityInfo = resolveInfo.activityInfo ?: return@mapNotNull null
                runCatching {
                    AppInfo(
                        label = resolveInfo.loadLabel(pm).toString(),
                        packageName = activityInfo.packageName,
                        activityClassName = activityInfo.name,
                        icon = resolveInfo.loadIcon(pm),
                    )
                }.getOrNull()
            }
            .distinctBy { it.packageName } // some apps expose more than one LAUNCHER activity
            .sortedBy { it.label.lowercase() }
    }
}
