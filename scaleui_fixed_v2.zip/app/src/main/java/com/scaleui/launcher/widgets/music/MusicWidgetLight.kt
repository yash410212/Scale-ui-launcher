package com.scaleui.launcher.widgets.music

import android.media.session.MediaController
import android.media.session.PlaybackState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface

/**
 * FINAL design (locked, do not redesign): light card — large circular
 * album art bleeding off the left edge, title/artist, progress bar,
 * prev/play/next, mute icon.
 */
@Composable
fun MusicWidgetLight(controller: MediaController?, onPlayPause: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit, modifier: Modifier = Modifier) {
    val metadata = controller?.metadata
    val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Nothing playing"
    val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
    val isPlaying = controller?.playbackState?.state == PlaybackState.STATE_PLAYING

    GlassSurface(modifier = modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(64.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)))
            Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text(artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Filled.SkipPrevious, null) }
                    IconButton(onClick = onPlayPause) { Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
                    IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, null) }
                }
            }
            Icon(Icons.Filled.VolumeOff, contentDescription = null, tint = Color.Gray)
        }
    }
}
