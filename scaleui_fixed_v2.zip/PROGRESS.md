# Scale UI — Build Progress

Send this file + SCALE_UI_ARCHITECTURE.md at the start of any new chat to continue exactly where we left off.
NOTE: per-part zips are no longer handed over — Claude keeps files in its workspace and delivers ONE combined zip (no build.yml inside it) once ALL parts are done.

## Status: Part 22 (Polish) DONE ✅ — ALL 21 PARTS + POLISH COMPLETE

### Part 1 — Project Setup
- [x] Gradle (Compose enabled, minSdk 26, navigation-compose + foundation deps)
- [x] AndroidManifest — HOME launcher intent-filter + QUERY_ALL_PACKAGES
- [x] AppInfo, AppRepository, AppLauncher — app discovery

### Part 2 — Home Screen (single page grid) — later absorbed into Part 3
- [x] home/model/HomeLayoutState.kt — HomeGridConfig (default 5x6) + HomeIconPlacement
- [x] home/HomeIcon.kt, home/HomeGrid.kt

### Part 3 — Multi-page home + HorizontalPager + wallpaper
- [x] home/HomePagerViewModel.kt — List<HomeLayoutState>, auto-fills pages by chunking installed apps
- [x] home/HomePager.kt — HorizontalPager wrapper + dot page indicator
- [x] home/HomeScreen.kt — hosts HomePager, transparent background, swipe-up-to-open-drawer gesture
- [x] core/apps/DrawableExt.kt — shared Drawable->Bitmap helper (moved out of HomeIcon)
- [x] themes.xml — windowShowWallpaper=true, transparent window background
- [x] MainActivity — FLAG_SHOW_WALLPAPER + transparent Surface

### Part 4 — App Drawer grid + A-Z scroll
- [x] drawer/AppDrawerViewModel.kt — exposes all installed apps (alphabetical)
- [x] drawer/AppDrawerScreen.kt — Pixel-style 4-column LazyVerticalGrid + side AZScrollBar
- [x] drawer/DrawerIcon.kt — white circular icon slot, `slotShape` param ready for Part 11's icon-shape setting
- [x] drawer/AZScrollBar.kt — drag-to-jump alphabet strip on the side edge
- [x] core/navigation/ScaleNavHost.kt — Home <-> Drawer routes (Zero Screen/Settings added later)
- [x] MainActivity rewired to host ScaleNavHost instead of a bare screen

### How to test (once combined zip is delivered)
1. Open in Android Studio, Gradle sync, run.
2. Home shows multiple swipeable pages (dot indicator at bottom) over your actual wallpaper, auto-filled with installed apps.
3. Swipe up on the home grid -> App Drawer opens: 4-column grid, all apps, drag the right-edge A-Z strip to jump.
4. System back button returns from Drawer to Home.
5. (Optional) Set as default Home app in Settings to test as a real launcher — still missing search, themes, folders etc.

---

## Up Next — Part 5
App Drawer search bar + transparency control (both layer on top of AppDrawerScreen, filtering/tinting the same `apps` list — no structural change needed).

## Remaining Parts
6. Theme engine skeleton
7–10. Themes: Frost Glass, Liquid Glass, Glass, Blur Mist
11. Settings: General + Home Screen Controls (+ real drag-drop icon placement, icon shape setting)
12. Folders (normal)
13. Folders (enlarged, swipeable, per final design)
14. Zero Screen
15. Widget Lab + music widgets + clock widget
16. Multi-profile: structure + switching + PIN
17. App visibility per profile + hidden apps
18. Gestures + double-tap-lock (replaces Part 3's fixed swipe-up-only gesture)
19. Custom shortcuts
20. App Freezer
21. Animation performance system
22. Polish + testing fixes

## Locked Design Decisions (see /areas/scale-ui.md for full detail)
- 4 themes mapped: Frosted→Frost Glass, Clear/iOS→Liquid Glass, colorful-glass-cards→Glass, Blur/One UI→Blur Mist
- Launcher icon: purple gradient shield badge, final
- 2 music widgets (dark + light) + 1 clock widget: final, must not be redesigned
- App Drawer: Pixel-style 4-col grid + icon shape option + A-Z scroll strip
- Folder (open): dark card, grid + Add button, swipe between folders
- Enlarged folder preview: fanned/overlapping icon stack
- Zero Screen: search + service cards + app usage bar + Brief Notes/Music/Calendar widgets
- 2 default home screens (yellow widget style + "Friday" nature style), user-customizable

### Part 5 — App Drawer search + transparency
- [x] drawer/DrawerSearchBar.kt — pill search bar, filters grid live
- [x] AppDrawerViewModel — added searchQuery + filteredApps (combine flow) + transparency StateFlow
- [x] AppDrawerScreen — search bar + tune icon toggles a transparency Slider controlling drawer scrim alpha (temporary inline control, moves into Settings in Part 11)
- [x] build.gradle — added material-icons-core (Search/Tune icons)

### Part 6 — Theme engine skeleton
- [x] theme/ThemeMode.kt — enum FROST_GLASS, LIQUID_GLASS, GLASS, BLUR_MIST, CUSTOM (mapped to the 4 locked reference images)
- [x] theme/GlassConfig.kt — visual tokens (tint, alpha, blur radius, border, corner radius)
- [x] theme/CustomThemeConfig.kt — placeholder user-tunable fields for CUSTOM mode
- [x] theme/ThemeEngine.kt — resolves ThemeMode -> GlassConfig with distinct starting values per theme
- [x] theme/ScaleTheme.kt — CompositionLocal wrapper (LocalGlassConfig, LocalThemeMode), wraps MaterialTheme
- [x] theme/GlassSurface.kt — shared glass-styled Box every screen should use going forward (uses Modifier.blur, gracefully no-ops on API<31)
- [x] MainActivity — now wraps content in ScaleTheme (defaults to GLASS) instead of plain MaterialTheme
- NOTE: existing screens (Home/Drawer) not yet retrofitted to use GlassSurface — that happens as each of Parts 7-10 lands, one theme/screen at a time

### Part 7 — Frost Glass theme (first theme retrofit)
- [x] ThemeEngine — refined FROST_GLASS token values (softer glow, more visible border halo)
- [x] GlassSurface — added `alphaOverride` param (lets Drawer's own transparency slider stay independent of theme alpha, per spec keeping them as separate controls)
- [x] DrawerSearchBar — retrofitted to real GlassSurface pill (was hardcoded color)
- [x] AppDrawerScreen — whole screen background now GlassSurface (RectangleShape, alphaOverride = the transparency slider value)
- [x] MainActivity — TEMPORARY dev-only theme switcher (5 dots, top-right) to visually test all 5 modes before Settings (Part 11) exists; defaults to FROST_GLASS
- NOTE: Home screen / HomeIcon still not retrofitted to GlassSurface — home icons have no card background in the final design (bare icon + label), so there may be nothing to retrofit there; revisit once folders/widgets (which DO have card backgrounds) land in Parts 12-15

### Part 8 — Liquid Glass theme
- [x] GlassConfig — added `hasSpecularHighlight` flag (any theme can opt into the refractive streak look, not hardcoded to one ThemeMode)
- [x] ThemeEngine — refined LIQUID_GLASS tokens (lower alpha, crisper minimal blur, brighter border) + enabled hasSpecularHighlight
- [x] GlassSurface — draws a soft diagonal light-streak overlay when the active theme has hasSpecularHighlight, on top of the tint/blur/border
- No screen changes needed — DrawerSearchBar/AppDrawerScreen automatically pick this up since they already use GlassSurface (Part 7); dev theme switcher (top-right dots) already lets Liquid Glass be tested

### Part 9 — Glass theme
- [x] GlassConfig — added `hasCornerHighlight` flag (soft radial glossy catch-light, distinct from Liquid Glass's diagonal streak)
- [x] ThemeEngine — refined GLASS tokens (darker neutral base so wallpaper/colors bleed through the alpha, moderate blur, moderate border) + enabled hasCornerHighlight
- [x] GlassSurface — draws a top-left radial gradient highlight when hasCornerHighlight is set
- No screen changes needed — same reasoning as Part 8; GLASS was already ScaleTheme's default mode

### Part 10 — Blur Mist theme (last of the 4 built-in themes)
- [x] GlassConfig — added `hasMistVignette` flag (soft radial edge-darkening instead of a highlight, for a diffused/misty read)
- [x] ThemeEngine — refined BLUR_MIST tokens (near-black base, highest alpha of all 4 themes, heaviest blur radius, no border) + enabled hasMistVignette
- [x] GlassSurface — draws a center-clear-to-edge-tinted radial vignette when hasMistVignette is set
- MILESTONE: all 4 built-in themes (Frost Glass, Liquid Glass, Glass, Blur Mist) are now implemented with distinct visual identities, switchable live via the dev theme switcher (top-right dots in MainActivity). CUSTOM mode exists in the enum/engine but has no highlight flags enabled yet and no UI to configure it — that's Part 11 (Settings) territory.

### Part 11 — Settings: General + Home Screen Controls
- [x] build.gradle — added datastore-preferences dependency
- [x] data/SettingsDataStore.kt — SettingsRepository wrapping Preferences DataStore: themeMode, isDarkMode, iconShape, homeGridConfig (columns/rows 1-10), with suspend setters
- [x] theme/IconShape.kt — enum CIRCLE/SQUIRCLE/ROUNDED_SQUARE/SQUARE + toComposeShape(), LocalIconShape CompositionLocal
- [x] theme/ScaleTheme.kt — now takes isDarkMode + iconShape params, provides LocalIconShape, picks light/dark MaterialTheme color scheme
- [x] home/HomeIcon.kt — icon now clipped to LocalIconShape.current (was always raw square/adaptive icon)
- [x] drawer/DrawerIcon.kt — slotShape now defaults from LocalIconShape.current instead of hardcoded CircleShape
- [x] home/HomePagerViewModel.kt — grid config now comes from SettingsRepository.homeGridConfig (persisted) instead of a hardcoded default, combined with installed apps
- [x] settings/SettingsViewModel.kt + settings/SettingsScreen.kt — General (dark/light switch), Theme picker (5 swatches), Icon Shape picker (4 swatches), Grid Size sliders (columns/rows 1-10) — all GlassSurface-styled sections
- [x] core/navigation/ScaleNavHost.kt — added "settings" route, threads SettingsRepository through
- [x] home/HomeScreen.kt — long-press opens Settings (onOpenSettings), alongside Part 4's swipe-up-for-Drawer
- [x] MainActivity — REMOVED Part 7's temporary dev theme switcher; theme/dark-mode/icon-shape now come live from SettingsViewModel (DataStore), persisted across app restarts
- NOTE: real drag-and-drop icon placement (moving icons between cells/pages) is DEFERRED past this part on purpose, to keep Part 11 focused on Settings + the theme/grid/icon-shape wiring. Home still auto-fills from installed apps (Part 3's logic, now settings-driven grid size). Slotting in manual placement later doesn't require changing HomeLayoutState's shape.

### Parts 12-16 (batched for speed)

**Part 12 — Folders (normal)**
- home/model/HomeLayoutState.kt: HomeIconPlacement now holds `HomeCellItem` (sealed: AppItem | FolderItem) instead of a bare AppInfo
- folders/FolderState.kt (ScaleFolder), folders/FolderOpenScreen.kt (dark card grid, GlassSurface)
- HomeGrid/HomePager/HomeScreen updated to dispatch app vs folder cells; folder opens as full-screen overlay
- HomePagerViewModel: DEMO overflow logic — apps beyond one page's capacity fold into a "More" folder, so folders are visibly testable without manual drag placement (which is still deferred)

**Part 13 — Folders (enlarged)**
- folders/FolderPreview.kt: locked design — fanned/overlapping 4-icon stack in a translucent rounded backdrop (not grid-in-circle)

**Part 14 — Zero Screen**
- data/SettingsDataStore.kt: added briefNote persistence
- zeroscreen/BriefNotesWidget.kt, ZeroCalendarWidget.kt, ZeroMusicWidget.kt (wraps MusicWidgetLight + MediaSessionBridge), ScreenTimeCard.kt (real UsageStatsManager query, degrades gracefully without Usage Access permission), ZeroScreenViewModel.kt, ZeroScreenScreen.kt
- ScaleNavHost: added zero_screen route; HomeScreen: swipe DOWN opens it (swipe up still = Drawer, long-press still = Settings)
- AndroidManifest: added PACKAGE_USAGE_STATS permission (special access, user must grant in system Settings)

**Part 15 — Widget Lab + final widgets**
- core/media/ScaleNotificationListenerService.kt + MediaSessionBridge.kt: reads whichever app is playing media system-wide (any app, e.g. YT Music) via MediaSessionManager; needs Notification Access granted in system Settings, degrades gracefully if not
- widgets/music/MusicWidgetDark.kt + MusicWidgetLight.kt: the 2 FINAL locked designs, both wired to MediaSessionBridge for real play/pause/next/prev control
- widgets/clock/ClockWidget.kt: FINAL locked design, live-updating every second
- widgets/WidgetLab.kt: ScaleWidgetType registry enum (CLOCK/MUSIC_DARK/MUSIC_LIGHT) — full widget-picker UI (add/resize/remove on Home) deferred alongside drag-and-drop placement
- build.gradle: swapped material-icons-core for material-icons-extended (needed for Pause/PlayArrow/SkipNext/Headset/VolumeOff/Tune/Search icons)
- AndroidManifest: added ScaleNotificationListenerService declaration

**Part 16 — Multi-profile (structure + switching + PIN)**
- profiles/ProfileState.kt (Profile enum: PROFILE_1/PROFILE_2), profiles/ProfileManager.kt (ViewModel: switch, PIN verify via SHA-256 hash)
- data/SettingsDataStore.kt: added currentProfile + pinHash persistence, setPin/verifyPin/setCurrentProfile
- settings/SettingsScreen.kt: new "Profile" section — shows active profile, PIN entry to switch (or set PIN if none yet)
- NOTE: per-app visibility filtering by profile (which apps actually show/hide per profile) is Part 17, NOT done yet — this part is only the switch mechanism + PIN gate

### Removed from plan
- Custom Shortcuts (was Part 19) — dropped per Yash's request to save time; not built, not planned.

### Parts 17, 18, 20, 21 (batched)

**Part 17 — App visibility per profile + hidden apps**
- profiles/AppVisibility.kt (BOTH/PROFILE_1_ONLY/PROFILE_2_ONLY/HIDDEN) + isVisibleIn()
- data/SettingsDataStore.kt: appVisibilityMap persisted (delimited string, apps default to BOTH unless listed)
- profiles/VisibilityFilter.kt: shared filterForProfile() used by both HomePagerViewModel and AppDrawerViewModel — a hidden/wrong-profile app never appears in either, including search
- AppDrawerScreen: long-press an icon -> AppContextMenu (set visibility / freeze / cancel)

**Part 18 — Gestures + Double-Tap-to-Lock**
- special/GestureController.kt: GestureTrigger (SWIPE_UP/DOWN, LONG_PRESS, DOUBLE_TAP) x GestureAction (OPEN_DRAWER/SETTINGS/ZERO_SCREEN, LOCK_SCREEN, NONE), DEFAULT_GESTURE_MAP
- data/SettingsDataStore.kt: gestureMap persisted, defaults merged with any saved overrides
- HomeScreen: all 4 gestures now dispatch through the map instead of being hardcoded; added double-tap detection
- core/admin/ScaleDeviceAdminReceiver.kt + res/xml/device_admin.xml + special/DoubleTapLock.kt: real screen lock via DevicePolicyManager.lockNow(), requires one-time Device Admin grant (prompts automatically if not yet active), no-ops otherwise
- Settings: new "Gestures" section — tap an action to cycle through options per trigger

**Part 20 — App Freezer**
- IMPORTANT Android limitation (spec itself anticipated this): a normal (non-Device-Owner, non-root) launcher CANNOT actually suspend/disable another app's process — that requires system-level privileges this app doesn't have. Implemented as a launcher-level SOFT freeze instead: frozen apps are dimmed + show a lock badge in the Drawer, and tapping one opens the context menu (to unfreeze) instead of launching directly. This is honest within Android's real constraints, not a full process freeze.
- data/SettingsDataStore.kt: frozenApps (Set<String>) persisted, toggleFrozen()
- DrawerIcon: isFrozen visual state; AppDrawerViewModel: frozenApps StateFlow + toggleFrozen()

**Part 21 — Animation performance system**
- animation/AnimationMode.kt: LIGHT/BALANCED/SMOOTH/CUSTOM -> AnimationConfig (transitionDurationMs, blurEnabled), LocalAnimationConfig
- ScaleTheme: new animationMode param, provides LocalAnimationConfig
- GlassSurface: blur is skipped ENTIRELY (not just theme-dependent) when the active AnimationMode disables it — real perf saving on LIGHT mode for low-end devices, on top of the existing API<31 auto-degradation
- Settings: new "Animation Performance" section, tap a mode to select
- NOTE: transitionDurationMs isn't wired into actual page-transition animations yet (HorizontalPager's default transition) — the value exists and is threaded through, applying it to specific transitions is a small follow-up whenever those are revisited

### Intentionally excluded
- Part 19 Custom Shortcuts — excluded from the active feature scope

## REMAINING: only Part 22 (polish/testing) is not done, and it's intentionally skipped. Every functional part (1-18, 20-21) is complete.

### Part 22 — Polish, debugging, bug fixes (done by Claude, not ChatGPT)

Full pass over all 51 Kotlin files + manifest + resources:

**Critical bug fixed (would have failed to build):**
- Launcher icon resources were NEVER created despite the manifest referencing `@mipmap/ic_launcher` since Part 1 — added `mipmap-anydpi-v26/ic_launcher.xml` (adaptive icon) + `drawable/ic_launcher_background.xml` + `drawable/ic_launcher_foreground.xml` (simplified vector version of the locked purple/pink Scale UI logo). minSdk 26 means adaptive-icon-only is sufficient, no legacy density PNGs needed.

**Real bugs fixed:**
- System back button did nothing while a folder was open on Home (FolderOpenScreen had no back handling) — added `BackHandler` to close the folder instead of falling through to whatever's behind Home in the nav stack.
- Same missing-back-handling bug in App Drawer's long-press context menu — added `BackHandler` there too.
- App Drawer's context menu rendered as a small unpositioned box that could overlap the search bar — rewritten as a proper centered dialog with a dimmed scrim behind it, tap-outside-to-dismiss.

**Consistency verified (no issues found):**
- Brace-balance check across all 51 files — clean.
- Cross-checked every ViewModel constructor against every call site in ScaleNavHost (AppDrawerViewModel/HomePagerViewModel signatures changed multiple times across Parts 11/17 — all call sites confirmed updated).
- Verified GlassSurface/ScaleTheme CompositionLocal chain is intact end to end (ThemeMode -> GlassConfig -> Surface rendering, AnimationMode -> AnimationConfig -> blur toggle, IconShape -> icon clipping).

**Minor cleanup:**
- Removed a couple of unused imports, bumped versionName to reflect actual progress (0.9.0).

## FINAL STATUS: 100% of the active Scale UI feature scope is implemented.
Custom Shortcuts remain intentionally excluded from the active scope. Android OS-level hard app freezing remains impossible for a normal launcher without privileged/device-owner access; Scale UI uses soft freeze.

## Completion pass — 2026-09-13
- [x] Real multi-page home paging based on grid capacity (removed demo-only overflow folder behavior).
- [x] Persistent Home app ordering via DataStore.
- [x] Long-press drag-and-drop app reordering with nearest-cell drop target.
- [x] Home widget placement persistence for Clock / Music Dark / Music Light.
- [x] Home widget add/remove/resize controls in Settings; selected widgets render on Home.
- [x] Fixed home grid row sizing so rows share available height instead of each requesting full height.
- [x] Added GitHub Actions build workflow for debug APK using JDK 17 + Gradle 8.6.

Note: Android's normal launcher sandbox still prevents a non-root/non-device-owner launcher from truly freezing another app process. Scale UI's App Freezer remains an honest soft-freeze implementation.
